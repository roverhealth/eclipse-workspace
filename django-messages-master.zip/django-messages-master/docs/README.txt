run

sphinx-build . build/

to build the documentation into the a directory named ./build/

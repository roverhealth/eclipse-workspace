class ForceGettingStartedMiddleware(object):

    def process_request(self, request):
        pass

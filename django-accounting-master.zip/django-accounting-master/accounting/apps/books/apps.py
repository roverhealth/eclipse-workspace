from django.apps import AppConfig


class FrenchBooksConfig(AppConfig):
    name = "accounting.apps.books"
    verbose_name = "Accounting Books"

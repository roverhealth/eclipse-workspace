default_app_config = 'accounting.apps.books.apps.FrenchBooksConfig'

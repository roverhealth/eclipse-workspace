default_app_config = 'tests.rest_framework.apps.RestFrameworkTestConfig'
